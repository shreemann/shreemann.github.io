---
layout: page
title: About
---

I'm not sure yet what this blog is about, but I'm sure I'll work it out soon.
